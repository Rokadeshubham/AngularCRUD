import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from './employee';


@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  url: string = "http://localhost:55195/api/Home";
  constructor(private _http:HttpClient) {

   }

   GetInfo():Observable<any>
   {
     return this._http.get<any>(this.url)
   }

   AddEmp(employee:Employee):Observable<Employee>{
    let httpHeaders = new HttpHeaders()
    .set('Content-Type','application/json');
    let options = {
      headers:httpHeaders
    };
    return this._http.post<Employee>(this.url,employee,options);
   }


   //Update
  updateEmp(employee:Employee){
    let httpHeaders = new HttpHeaders()
      .set('Content-Type', 'application/json');
    let options = {
      headers: httpHeaders
    };
    this._http.put<Employee>(this.url, employee, options).toPromise();
  }

  //Delete
  DeleteEmp(id){
    let headers = new HttpHeaders()
      .set('Content-Type', 'application/json');
    this._http.delete("http://localhost:55195/api/Home/"+id,{headers}).toPromise();
  }


  //Single Employee
  SingleEmp(id:number):Observable<any>{
    return this._http.get<any>("http://localhost:55195/api/Home/" + id);
  }
}
