export interface Employee {
    FirstName:String,
    LastName:String,
    EmpCode:String,
    Position:String,
    Office:String
}
