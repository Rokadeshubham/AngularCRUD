import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Employee } from '../employee';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent {

  empDetails = [];
  updateForm:FormGroup;
  constructor(private _service:EmployeeService,private formbuilder:FormBuilder) { 
    _service.GetInfo().subscribe(s=>this.empDetails=s)
  }

  //Edit
  Edit(e){
    this.updateForm.setValue(e);
  }
ngOnInit(){
  this.updateForm = this.formbuilder.group({
    EmployeeId: ['', [Validators.required]],
    FirstName: ['', [Validators.required]],
    LastName: ['', [Validators.required]],
    EmpCode: ['', [Validators.required]],
    Position: ['', [Validators.required]],
    Office: ['', [Validators.required]]
  })
}

  OnFormUpdate(){
    let employee = this.updateForm.value;
    this.update(employee);
    this.updateForm.reset();
  }

  update(employee:Employee){
    this._service.updateEmp(employee);
  }

  //Delete
  Delete(e){
    this._service.DeleteEmp(e);
  }
//Single Employee
  singleEmpDetails;
  Details(e){
    this._service.SingleEmp(e).subscribe(s => this.singleEmpDetails=s);
  }
}
