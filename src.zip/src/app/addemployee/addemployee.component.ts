import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormGroup, Validators } from '@angular/forms'

import { Employee } from '../employee';

@Component({
  selector: 'app-addemployee',
  templateUrl: './addemployee.component.html',
  styleUrls: ['./addemployee.component.css']
})
export class AddemployeeComponent{
  empForm:FormGroup;
  datasaved:true;
  constructor(private _service:EmployeeService,private toastr:ToastrService,private formbuilder:FormBuilder) { }

  ngOnInit() {
    this.empForm = this.formbuilder.group({
      FirstName: ['',[Validators.required]],
      LastName:['',[Validators.required]],
      EmpCode:['',[Validators.required]],
      Position:['',[Validators.required]],
      Office:['',[Validators.required]]
    })
  }

    onFormSubmit(){
      let employee = this.empForm.value;
      this.create(employee);
      this.empForm.reset();
    }
    create(employee:Employee){
      this._service.AddEmp(employee).subscribe(employee=>{this.datasaved=true;
        this.toastr.success('New Record Inserted', 'EMployee Reg');
      })
    }

  

}
