import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddemployeeComponent } from './addemployee/addemployee.component';
import { DisplayComponent } from './display/display.component';

const routes: Routes = [
  {path:"AddEmployee",component:AddemployeeComponent},
  {path:"DisplayAllDetails",component:DisplayComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
